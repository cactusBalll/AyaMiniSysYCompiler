package ty;

public class IntTy extends Ty{
    private static final IntTy instance = new IntTy();

    public static IntTy build() {
        return instance;
    }
}
