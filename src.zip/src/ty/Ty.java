package ty;

public class Ty {
}
