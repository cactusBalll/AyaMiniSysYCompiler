package ty;

/**
 * 占位
 */
public class NullTy extends Ty{
    private static final NullTy instance = new NullTy();

    public static NullTy getInstance() {
        return instance;
    }
}
