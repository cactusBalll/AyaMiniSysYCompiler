package ty;

public class PointerTy extends Ty{
    private final Ty inner;
    private PointerTy(Ty inner) {
        this.inner = inner;
    }

    public static PointerTy build(Ty inner) {
        return new PointerTy(inner);
    }

    public Ty getInner() {
        return inner;
    }
}
